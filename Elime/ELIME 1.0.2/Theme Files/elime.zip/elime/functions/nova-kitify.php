<?php

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class Nova_Kitify {

  function __construct($settings = []) {
    add_action( 'kitify/wooproduct/loop_action', array( $this, 'custom_loop_action' ), 10 );
  }
  public function custom_loop_action() {
    add_action('woocommerce_before_shop_loop',  'kitify_setup_toolbar' , -999 );
    add_action('woocommerce_before_shop_loop',  'kitify_add_toolbar_open' , 15 );
    add_action('woocommerce_before_shop_loop',  'kitify_add_toolbar_close' , 35 );
    add_action( 'nova_woocommerce_catalog_ordering', 'kitify_add_grid_list_display', 35, 0 );
    add_action('kitify/products/action/shop_loop_item_action', 'woocommerce_template_loop_add_to_cart', 40);

    add_action('kitify/products/action/shop_loop_item_footer', 'woocommerce_template_loop_add_to_cart', 10);

    remove_action('woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open');
    remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5);
    remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
    remove_action('woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10);
    remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
    remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
    remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5);

    add_action( 'woocommerce_before_shop_loop_item', [ $this, 'loop_item_open' ], -1001 );
    add_action( 'woocommerce_after_shop_loop_item', [ $this, 'loop_item_close' ], 1001 );

    add_action('woocommerce_before_shop_loop_item_title', [ $this, 'loop_item_thumbnail_open' ], -1001 );
    add_action('woocommerce_before_shop_loop_item_title', [ $this, 'loop_item_thumbnail_close' ], 1001 );

    add_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_open', -101 );
    add_action('woocommerce_before_shop_loop_item_title', [ $this, 'add_product_thumbnails_to_loop' ], 15 );
    add_action('woocommerce_before_shop_loop_item_title', [ $this, 'loop_item_thumbnail_overlay' ], 100 );
    add_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_close', 101 );

    remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);
    add_action( 'kitify/products/action/shop_loop_item_after_title', 'woocommerce_template_loop_price', 10);

    add_action('woocommerce_shop_loop_item_title', [ $this, 'loop_item_info_open' ], -101 );
    add_action('kitify/products/action/shop_loop_item_title', [ $this, 'loop_item_add_product_title' ], 10 );
    add_action('woocommerce_after_shop_loop_item', [ $this, 'loop_item_info_close' ], 101 );
    add_action( 'kitify/products/action/desc_footer', [ $this, 'add_product_loop_rating' ], 10);
    add_action('kitify/products/action/desc_footer', [ $this, 'add_product_loop_category' ], 15 );

    remove_action('woocommerce_after_shop_loop', 'woocommerce_pagination', 10);
    add_action( 'woocommerce_after_shop_loop', [ $this, 'woocommerce_pagination' ], 10 );
  }
  public function loop_item_open(){
      echo '<div class="product-item">';
  }
  public function loop_item_close(){
      echo '</div>';
  }
  public function loop_item_thumbnail_open(){
      echo '<div class="product-item__thumbnail">';
      echo '<a class="product-item-link" href="'.get_the_permalink().'"></a>';
      echo '<div class="product-item__description--actions">';
      do_action('kitify/products/action/shop_loop_item_action');
      echo '</div>';
      do_action('kitify/products/action/shop_loop_item_button');
      echo '<div class="product-item__badges">';
      do_action( 'woocommerce_product_badges' );
      echo '</div>';
      echo '<div class="product-item__thumbnail-placeholder">';
  }
  public function loop_item_thumbnail_close(){
          echo '</div>';
      echo '</div>';
  }
  public function loop_item_thumbnail_overlay(){
      echo '<div class="product-item__thumbnail_overlay"></div>';
  }

  public function loop_item_info_open(){
      echo '<div class="product-item__description">';
          echo '<div class="product-item__description--info">';
          echo '<div class="info-left">';
          do_action('kitify/products/action/shop_loop_item_title');
          echo '</div>';
          echo '<div class="info-right">';
          do_action('kitify/products/action/shop_loop_item_after_title');
          echo '</div>';

  }
  public function loop_item_info_close(){
          echo '</div>';
          echo '<div class="product-item__description--footer">';
          if( !empty(wc_get_loop_prop('enable_p_rating')) ) {
            do_action('kitify/products/action/desc_footer');
          }
          echo '</div>';
      echo '</div>';
  }

  public function loop_item_short_description() {
    global $product;
    echo '<div class="product-short-description">';
    echo $product->get_short_description(); // PHPCS: XSS ok
    echo '</div>';
  }

  public function loop_item_footer_open(){
    echo '<div class="product-item-footer">';
    do_action( 'kitify/products/action/shop_loop_item_footer' );
  }
  public function loop_item_footer_close(){
    echo '</div>';
  }
  public function loop_item_hover_box(){
    echo '<div class="product-item-hover"></div>';
  }
  public function loop_item_add_product_title(){
      $html_tag = wc_get_loop_prop('kitify_item_html_tag', 'h2');
      $html_tag = kitify_helper()->validate_html_tag($html_tag);
      the_title( sprintf( '<a href="%1s" class="title"><%2$s class="woocommerce-loop-product__title">', esc_url( get_the_permalink() ), $html_tag ), sprintf('</%1$s></a>', $html_tag) );
  }
  public function add_product_thumbnails_to_loop(){
      $image_size = wc_get_loop_prop('kitify_image_size', 'woocommerce_thumbnail');
      $enable_alt_image = wc_get_loop_prop('kitify_enable_alt_image', false);

      global $product;

      $output = woocommerce_get_product_thumbnail( $image_size );
      if($enable_alt_image){
          $gallery_image_ids = $product->get_gallery_image_ids();
          if(!empty($gallery_image_ids[0])){
              $image_url = wp_get_attachment_image_url($gallery_image_ids[0], $image_size);
              $output .= sprintf('<span class="product_second_image" style="background-image: url(\'%1$s\')"></span>', esc_url( $image_url ));
          }
      }
      echo $output; // PHPCS: XSS ok
  }
  public function add_product_loop_rating() {
    $enable_rating = wc_get_loop_prop('enable_p_rating', false);
    if($enable_rating) {
      return woocommerce_template_loop_rating();
    }
  }
  public function add_product_loop_category() {
    global $product;
    $enable_category = wc_get_loop_prop('kitify_enable_product_cat', false);

    if($enable_category) {
      $categories = explode(', ', wc_get_product_category_list( $product->get_id() ) );
      $categories = array_filter( $categories );
      $i = 0;
      if ( !empty( $categories ) ) :
        echo '<div class="product-item__category">';
        foreach ( $categories as $category ):
          if ( $i < 1 ) {
          echo preg_replace('/(<a)(.+\/a>)/i', '${1} class="content-product-cat" ${2}', $category);
          }
          $i++;
        endforeach;
        echo '</div>';
      endif;
    }
  }

  public function woocommerce_pagination(){
      ob_start();
      woocommerce_pagination();
      $output = ob_get_clean();

      $output = str_replace('woocommerce-pagination', 'woocommerce-pagination kitify-pagination clearfix kitify-ajax-pagination', $output);

      echo $output; // PHPCS: XSS ok
  }
}
$Nova_Kitify = new Nova_Kitify;
