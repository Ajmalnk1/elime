<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

add_filter('kitify/logo/attr/src', 'elime_kitify_logo_attr_src');
if(!function_exists('elime_kitify_logo_attr_src')){
    function elime_kitify_logo_attr_src( $src ){
        if(!$src){
	        $src = esc_url( Nova_OP::getOption('header_logo') );
        }
        return $src;
    }
}

add_filter('kitify/logo/attr/src4l', 'elime_kitify_logo_attr_src4l');
if(!function_exists('elime_kitify_logo_attr_src4l')){
    function elime_kitify_logo_attr_src4l( $src ){
        if(!$src){
	        $src = esc_url( Nova_OP::getOption('header_logo_light') );
        }
        return $src;
    }
}

add_filter('kitify/logo/attr/width', 'elime_kitify_logo_attr_width');
if(!function_exists('elime_kitify_logo_attr_width')){
    function elime_kitify_logo_attr_width( $value ){
        if(!$value){
            $value = esc_html(Nova_OP::getOption('header_logo_width'));
        }
        return $value;
    }
}

add_action('elementor/frontend/widget/before_render', 'elime_kitify_add_class_into_sidebar_widget');
if(!function_exists('elime_kitify_add_class_into_sidebar_widget')){
    function elime_kitify_add_class_into_sidebar_widget( $widget ){
        if('sidebar' == $widget->get_name()){
            $widget->add_render_attribute('_wrapper', 'class' , 'widget-area');
        }

    }
}
add_filter('kitify/nova-menu/control/style', 'elime_kitify_add_nova_menu_style');
if(!function_exists('elime_kitify_add_nova_menu_style')){
    function elime_kitify_add_nova_menu_style(){
        return [
          'default' => esc_html__( 'Default', 'elime' ),
          'left_dot' => esc_html__( 'Left Dot', 'elime' ),
        ];
    }
}
add_filter('kitify/nova-menu-cart/control/preset', 'elime_kitify_add_nova_cart_style');
if(!function_exists('elime_kitify_add_nova_cart_style')){
    function elime_kitify_add_nova_cart_style(){
        return [
          'default' => esc_html__( 'Default', 'elime' ),
          'elime' => esc_html__( 'Elime', 'elime' ),
        ];
    }
}
add_filter('kitify/banner/control/animation_effect', 'elime_kitify_add_banner_animation_effect');
if(!function_exists('elime_kitify_add_banner_animation_effect')){
    function elime_kitify_add_banner_animation_effect(){
        return [
          'none'   => esc_html__( 'None', 'elime' ),
          'hidden-content'   => esc_html__( 'Hidden Content', 'elime' ),
          'elime-1'   => esc_html__( 'Elime', 'elime' ),
					'lily'   => esc_html__( 'Lily', 'elime' ),
					'sadie'  => esc_html__( 'Sadie', 'elime' ),
					'layla'  => esc_html__( 'Layla', 'elime' ),
					'oscar'  => esc_html__( 'Oscar', 'elime' ),
					'marley' => esc_html__( 'Marley', 'elime' ),
					'ruby'   => esc_html__( 'Ruby', 'elime' ),
					'roxy'   => esc_html__( 'Roxy', 'elime' ),
					'bubba'  => esc_html__( 'Bubba', 'elime' ),
					'romeo'  => esc_html__( 'Romeo', 'elime' ),
					'sarah'  => esc_html__( 'Sarah', 'elime' ),
					'chico'  => esc_html__( 'Chico', 'elime' ),
        ];
    }
}

add_filter('kitify/products/control/grid_style', 'elime_kitify_add_product_grid_style');
if(!function_exists('elime_kitify_add_product_grid_style')){
    function elime_kitify_add_product_grid_style(){
        return [
            '1' => esc_html__('Default', 'elime'),
            '2' => esc_html__('Style 02', 'elime'),
            '3' => esc_html__('Fashion Style', 'elime'),
        ];
    }
}

add_filter('kitify/products/control/list_style', 'elime_kitify_add_product_list_style');
if(!function_exists('elime_kitify_add_product_list_style')){
    function elime_kitify_add_product_list_style(){
        return [
            '1' => esc_html__('Type 1', 'elime'),
            'mini' => esc_html__('Mini', 'elime'),
        ];
    }
}
add_filter('kitify/woo-categories/control/preset', 'elime_kitify_add_woo_categories_style');
if(!function_exists('elime_kitify_add_woo_categories_style')){
    function elime_kitify_add_woo_categories_style(){
        return [
          'default' => esc_html__( 'Default', 'elime' ),
          'type-01' => esc_html__( 'Elime 01', 'elime' ),
          'type-02' => esc_html__( 'Elime 02', 'elime' ),
        ];
    }
}
add_filter('kitify/posts/control/preset', 'elime_kitify_add_posts_preset');
if(!function_exists('elime_kitify_add_posts_preset')){
    function elime_kitify_add_posts_preset(){
        return [
          'grid-1' => esc_html__( 'Grid 1', 'elime' ),
					'grid-2' => esc_html__( 'Grid 2', 'elime' ),
					'list-1' => esc_html__( 'List 1', 'elime' ),
					'list-2' => esc_html__( 'List 2', 'elime' ),
          'elime-1' => esc_html__( 'Elime Style', 'elime' ),
        ];
    }
}
add_filter('kitify/tabs/control/preset', 'elime_kitify_add_tabs_preset');
if(!function_exists('elime_kitify_add_tabs_preset')){
    function elime_kitify_add_tabs_preset(){
        return [
          'default' => esc_html__( 'Default', 'elime' ),
          'elime-1' => esc_html__( 'Elime Style', 'elime' ),
          'elime-2' => esc_html__( 'Elime Style 02', 'elime' ),
        ];
    }
}

add_filter('kitify/products/box_selector', 'elime_kitify_product_change_box_selector');
if(!function_exists('elime_kitify_product_change_box_selector')){
    function elime_kitify_product_change_box_selector(){
        return '{{WRAPPER}} ul.products .product-item';
    }
}

add_filter('kitify/posts/format-icon', 'elime_kitify_change_postformat_icon', 10, 2);
if(!function_exists('elime_kitify_change_postformat_icon')){
    function elime_kitify_change_postformat_icon( $icon, $type ){
        return $icon;
    }
}
add_filter('kitify/sidebar/style/sidebar_style', 'elime_kitify_add_sidebar_style');
if(!function_exists('elime_kitify_add_sidebar_style')){
    function elime_kitify_add_sidebar_style(){
        return [
            '1' => esc_html__('Default', 'elime'),
            '2' => esc_html__('Shop Sidebar', 'elime'),
        ];
    }
}
add_filter('kitify/wootabs/layout/tabs_layout', 'elime_kitify_tabs_layout');
if(!function_exists('elime_kitify_tabs_layout')){
    function elime_kitify_tabs_layout(){
        return [
            'default' => esc_html__('Default', 'elime'),
            'tab_left' => esc_html__('Tabs left', 'elime'),
            'accordion' => esc_html__('Accordion', 'elime'),
        ];
    }
}
// -----------------------------------------------------------------------------
// Elementor register breakpoint
// -----------------------------------------------------------------------------

if ( ! function_exists( 'elime_register_breakpoint' ) ) :
function elime_register_breakpoint(){
  if(defined('ELEMENTOR_VERSION')){
      $has_register_breakpoint = get_option('elime_has_register_breakpoint', false);
      if(empty($has_register_breakpoint)){
          update_option('elementor_experiment-additional_custom_breakpoints', 'active');
          $kit_active_id = Elementor\Plugin::$instance->kits_manager->get_active_id();
          $raw_kit_settings = get_post_meta( $kit_active_id, '_elementor_page_settings', true );
          if(empty($raw_kit_settings)){
            $raw_kit_settings = [];
          }
          $default_settings = [
              'space_between_widgets' => '0',
              'page_title_selector' => 'h1.entry-title',
              'stretched_section_container' => '',
              'active_breakpoints' => [
                  'viewport_mobile',
                  'viewport_mobile_extra',
                  'viewport_tablet',
                  'viewport_tablet_extra',
                  'viewport_laptop',
              ],
              'viewport_mobile' => 767,
              'viewport_md' => 768,
              'viewport_mobile_extra' => 991,
              'viewport_tablet' => 1024,
              'viewport_tablet_extra' => 1279,
              'viewport_lg' => 1280,
              'viewport_laptop' => 1599,
              'system_colors' => [
                [
                  '_id' => 'primary',
                  'title' => esc_html__( 'Primary', 'elime' )
                ],
                [
                  '_id' => 'secondary',
                  'title' => esc_html__( 'Secondary', 'elime' )
                ],
                [
                  '_id' => 'text',
                  'title' => esc_html__( 'Text', 'elime' )
                ],
                [
                  '_id' => 'accent',
                  'title' => esc_html__( 'Accent', 'elime' )
                ]
              ],
              'system_typography' => [
                [
                  '_id' => 'primary',
                  'title' => esc_html__( 'Primary', 'elime' )
                ],
                [
                  '_id' => 'secondary',
                  'title' => esc_html__( 'Secondary', 'elime' )
                ],
                [
                  '_id' => 'text',
                  'title' => esc_html__( 'Text', 'elime' )
                ],
                [
                  '_id' => 'accent',
                  'title' => esc_html__( 'Accent', 'elime' )
                ]
              ]
          ];
          $raw_kit_settings = array_merge($raw_kit_settings, $default_settings);
          update_post_meta( $kit_active_id, '_elementor_page_settings', $raw_kit_settings );
          Elementor\Core\Breakpoints\Manager::compile_stylesheet_templates();
          update_option('elime_has_register_breakpoint', true);
      }
  }
}
endif;
add_action( 'elementor/init', 'elime_register_breakpoint' );

/**
 * Add support for Elementor Pro locations
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'elime_register_elementor_locations' ) ) :
  function elime_register_elementor_locations( $elementor_theme_manager ) {
      $elementor_theme_manager->register_all_core_location();
  }
endif;
// Add support for Elementor Pro locations
add_action( 'elementor/theme/register_locations', 'elime_register_elementor_locations' );
