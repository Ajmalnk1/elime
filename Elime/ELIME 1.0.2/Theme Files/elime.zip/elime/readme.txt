Theme Name: Elime
Theme URI: http://elime.novaworks.net/
Author: Novaworks
Author URI: https://www.novaworks.net/
Description: Elime is a fully responsive Premium WordPress Theme with a pixel perfect design and extensive functionality.
Requires at least: 4.9.6
Tested up to: 5.5
Requires PHP: 5.2.4
Version: 1.0.0
Tags: one-column, two-columns, three-columns, four-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-menu, featured-image-header, featured-images, flexible-header, full-width-template, post-formats, sticky-post, theme-options, translation-ready
License: 		GNU General Public License
License URI: 	licence/GPL.txt
Text Domain: elime

= 1.0.0 =
* Released: December 28, 2021
