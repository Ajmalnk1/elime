<div class="site-content styling__quickview" id="nova_wc_quickview">
		<div class="nova_wc_quickview__content site-content"></div>
</div>
