<footer class="site-footer">
	<div class="nova-footer footer-type-1">

		<div class="row small-collapse">
			<div class="large-12 columns">

				<div class="nova-footer__copyright-text">
					<div class="footer-text">
						<?php echo Nova_OP::getOption('footer_text') ?>
					</div>
				</div>

			</div>
		</div>

	</div>

</footer>
