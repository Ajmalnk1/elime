<!-- Post thumbnail <?php the_ID(); ?> -->
<div class="swiper-slide">
		<div class="cover-slider" data-bg="<?php the_post_thumbnail_url('large'); ?>"><a class="swiper-slide__link" href="<?php echo esc_url( get_permalink() ); ?>"></a></div>
</div>
<!-- /Post thumbnail <?php the_ID(); ?> -->
