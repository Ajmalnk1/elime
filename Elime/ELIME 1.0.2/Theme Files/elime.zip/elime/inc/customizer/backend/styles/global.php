<?php
$sep_id  = 4544;
$section = 'style_global';

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'bg_color',
    'label'       => esc_html__( 'Body Background', 'elime' ),
    'section'     => $section,
    'default'     => '#FFF',
    'priority'    => 10,
) );

// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'primary_color',
    'label'       => esc_html__( 'Main Font Color', 'elime' ),
    'section'     => $section,
    'default'     => '#777777',
    'priority'    => 10,
) );

// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'secondary_color',
    'label'       => esc_html__( 'Secondary Font Color', 'elime' ),
    'section'     => $section,
    'default'     => '#131313',
    'priority'    => 10,
) );

// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'accent_color',
    'label'       => esc_html__( 'Accent Color', 'elime' ),
    'section'     => $section,
    'default'     => '#cf736e',
    'priority'    => 10,
) );

// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );
// ---------------------------------------------

// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'accent_color_2',
    'label'       => esc_html__( 'Accent Color 2', 'elime' ),
    'section'     => $section,
    'default'     => '#d9f293',
    'priority'    => 10,
) );

// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'border_color',
    'label'       => esc_html__( 'Border Color', 'elime' ),
    'section'     => $section,
    'default'     => '#f8f8f8',
    'priority'    => 10,
) );
// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'site_link_color',
    'label'       => esc_html__( 'Link Color', 'elime' ),
    'section'     => $section,
    'default'     => '#131313',
    'priority'    => 10,
) );
// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'site_link_hover_color',
    'label'       => esc_html__( 'Link Hover Color', 'elime' ),
    'section'     => $section,
    'default'     => '#CF736E',
    'priority'    => 10,
) );
// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'primary_button_color',
    'label'       => esc_html__( 'Primary Button Color', 'elime' ),
    'section'     => $section,
    'default'     => '#CF736E',
    'priority'    => 10,
) );
// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'secondary_button_color',
    'label'       => esc_html__( 'Secondary Button Color', 'elime' ),
    'section'     => $section,
    'default'     => '#131313',
    'priority'    => 10,
) );
// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'number',
    'settings'    => 'button_radius',
    'label'       => esc_html__( 'Button Radius', 'elime' ),
    'section'     => $section,
    'default'     => 5,
    'priority'    => 10,
    'choices'     => array(
        'min'  => 0,
        'max'  => 100,
        'step' => 1
    ),
) );
// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,
) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'number',
    'settings'    => 'field_radius',
    'label'       => esc_html__( 'Field Radius', 'elime' ),
    'section'     => $section,
    'default'     => 5,
    'priority'    => 10,
    'choices'     => array(
        'min'  => 0,
        'max'  => 100,
        'step' => 1
    ),
) );
