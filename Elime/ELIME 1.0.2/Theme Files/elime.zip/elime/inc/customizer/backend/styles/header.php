<?php
$sep_id  = 77953;
$section = 'style_header';

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'header_background_color',
    'label'       => esc_html__( 'Header Background Color', 'elime' ),
    'section'     => $section,
    'default'     => '#131313',
    'priority'    => 10,

) );

// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,

) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'header_background_color_2',
    'label'       => esc_html__( 'Header Secondary Background Color', 'elime' ),
    'section'     => $section,
    'default'     => '#F6F6F6',
    'priority'    => 10,

) );

// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,

) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'header_font_color',
    'label'       => esc_html__( 'Header Text Color', 'elime' ),
    'section'     => $section,
    'default'     => '#ffffff',
    'priority'    => 10,

) );

// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,

) );
// ---------------------------------------------

Kirki::add_field( 'elime', array(
    'type'        => 'color',
    'settings'    => 'header_accent_color',
    'label'       => esc_html__( 'Header Accent Color', 'elime' ),
    'section'     => $section,
    'default'     => '#cf736e',
    'priority'    => 10,

) );

// ---------------------------------------------
Kirki::add_field( 'elime', array(
    'type'        => 'separator',
    'settings'    => 'separator_'. $sep_id++,
    'section'     => $section,

) );
// ---------------------------------------------
