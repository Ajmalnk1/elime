<?php if ( ! is_active_sidebar( 'blog-widget-area' ) ) return; ?>

<aside class="site-sidebar site-sidebar--blog widget-area">
	<?php dynamic_sidebar( 'blog-widget-area' ); ?>
</aside><!-- .site-sidebar -->
